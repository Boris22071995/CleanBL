package org.unibl.etf.ps.cleanbl.exception;

public class TokenException extends RuntimeException {
    public TokenException() {
        super();
    }

    public TokenException(String message) {
        super(message);
    }
}
