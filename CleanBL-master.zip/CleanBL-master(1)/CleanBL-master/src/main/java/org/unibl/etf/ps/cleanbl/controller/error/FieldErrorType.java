package org.unibl.etf.ps.cleanbl.controller.error;

public enum FieldErrorType {
    REQUIRED,
    INVALID,
}
