package org.unibl.etf.ps.cleanbl.exception;

public class VerificationTokenException extends IllegalArgumentException {
    public VerificationTokenException() {
        super();
    }

    public VerificationTokenException(String message) {
        super(message);
    }
}
