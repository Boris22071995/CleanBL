ALTER TABLE DepartmentService CHANGE COLUMN address email varchar(255) NOT NULL;
