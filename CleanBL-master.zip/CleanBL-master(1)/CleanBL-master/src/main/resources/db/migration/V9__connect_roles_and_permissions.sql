INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 2 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 3 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 4 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 5 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 6 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 7 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 8 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 13 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 14 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 15 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 16 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 17 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 18 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 19 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 20 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 21 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 22 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 23 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 24 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 25 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 26 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 27 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 1, 28 );

INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 2, 7 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 2, 10 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 2, 11 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 2, 12 );

INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 3, 1 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 3, 2 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 3, 3 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 3, 4 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 3, 9 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 3, 10 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 3, 11 );
INSERT INTO RoleHasPermissions ( roleId, permissionId ) VALUES ( 3, 12 );



