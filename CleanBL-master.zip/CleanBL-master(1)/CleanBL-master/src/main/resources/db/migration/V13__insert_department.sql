INSERT INTO Department (Name, Phone, Email) VALUES ('Odjeljenje za saobraćaj i puteve', '051/244-425', 'saobracaj.i.putevi@banjaluka.rs.ba');
INSERT INTO Department (Name, Phone, Email) VALUES ('Odjeljenje komunalne policije', '051/348-842', 'komunalna.policija@banjaluka.rs.ba');
