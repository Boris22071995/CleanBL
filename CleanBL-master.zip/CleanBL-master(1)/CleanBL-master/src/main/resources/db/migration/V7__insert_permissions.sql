INSERT INTO Permission ( Name ) VALUES ( "EndUser_Create" );
INSERT INTO Permission ( Name ) VALUES ( "EndUser_Read" );
INSERT INTO Permission ( Name ) VALUES ( "EndUser_Update" );
INSERT INTO Permission ( Name ) VALUES ( "EndUser_Delete" );

INSERT INTO Permission ( Name ) VALUES ( "DepartmentOfficer_Create" );
INSERT INTO Permission ( Name ) VALUES ( "DepartmentOfficer_Read" );
INSERT INTO Permission ( Name ) VALUES ( "DepartmentOfficer_Update" );
INSERT INTO Permission ( Name ) VALUES ( "DepartmentOfficer_Delete" );

INSERT INTO Permission ( Name ) VALUES ( "Report_Create" );
INSERT INTO Permission ( Name ) VALUES ( "Report_Read" );
INSERT INTO Permission ( Name ) VALUES ( "Report_Update" );
INSERT INTO Permission ( Name ) VALUES ( "Report_Delete" );

INSERT INTO Permission ( Name ) VALUES ( "Department_Create" );
INSERT INTO Permission ( Name ) VALUES ( "Department_Read" );
INSERT INTO Permission ( Name ) VALUES ( "Department_Update" );
INSERT INTO Permission ( Name ) VALUES ( "Department_Delete" );

INSERT INTO Permission ( Name ) VALUES ( "DepartmentService_Create" );
INSERT INTO Permission ( Name ) VALUES ( "DepartmentService_Read" );
INSERT INTO Permission ( Name ) VALUES ( "DepartmentService_Update" );
INSERT INTO Permission ( Name ) VALUES ( "DepartmentService_Delete" );

INSERT INTO Permission ( Name ) VALUES ( "Street_Create" );
INSERT INTO Permission ( Name ) VALUES ( "Street_Read" );
INSERT INTO Permission ( Name ) VALUES ( "Street_Update" );
INSERT INTO Permission ( Name ) VALUES ( "Street_Delete" );

INSERT INTO Permission ( Name ) VALUES ( "PartOfTheCity_Create" );
INSERT INTO Permission ( Name ) VALUES ( "PartOfTheCity_Read" );
INSERT INTO Permission ( Name ) VALUES ( "PartOfTheCity_Update" );
INSERT INTO Permission ( Name ) VALUES ( "PartOfTheCity_Delete" );
