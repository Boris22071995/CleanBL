INSERT INTO ReportStatus (Name) VALUES ("poslan");
INSERT INTO ReportStatus (Name) VALUES ("u procesu");
INSERT INTO ReportStatus (Name) VALUES ("zavrsen");
