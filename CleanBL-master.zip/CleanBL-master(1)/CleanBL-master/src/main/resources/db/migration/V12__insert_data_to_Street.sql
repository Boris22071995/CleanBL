INSERT INTO Street (name, partOfTheCityId) VALUES ("Veljka Mlađenovića", '1');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Ada", '1');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Raska Petrovića", '1');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Braće Kukurika", '1');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Petri prigradski put", '1');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Bulevar vojvode Živojima Mišića", '2');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Miše Stupara", '2');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Bore Stankovića", '2');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Vojvode Radomira Putnika", '2');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Aleja Svetog Save", '2');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Gundulićeva", '2');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Save Kovačevića", '2');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Marije Bursać", '3');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Zmaj Jovina", '3');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Jovana Dučića", '3');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Sime Matavulja", '3');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Bulevar cara Dušana", '3');


INSERT INTO Street (name, partOfTheCityId) VALUES ("Vladislava Skarića", '4');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Carigradska", '4');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Siniše Mijatovića", '4');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Siniše Mijatovića", '4');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Mis Adeline Irbi", '4');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Miloša Pocerca", '4');


INSERT INTO Street (name, partOfTheCityId) VALUES ("Duška Koščice", '5');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Solunska", '5');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Skendera Kulenovića", '5');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Kozarska", '5');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Filipa Macure", '5');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Kraljice Marije", '6');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Stojana Jankovića", '6');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Petra Pecije", '6');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Marka Lipovca", '6');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Plitvička", '6');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Šumadijska", '6');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Alekse Dundića", '6');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Knjaza Miloša", '6');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Srpskih rudara", '7');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Vlašićka", '7');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Velebitska", '7');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Sanska", '7');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Bose Živković", '7');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Vladike Varnave Nastića", '7');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Vida Simurdžića", '7');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Svetozara Markovića", '8');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Petra Preradovića", '8');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Petra Rađenovića", '8');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Pave Radana", '8');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Masarikova", '8');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Slobodana Jovanovića", '8');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Starine Novaka", '9');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Banović Strahinje", '9');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Miloša Obilića", '9');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Krfska", '9');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Mileševska", '9');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Pionirska", '9');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Zelengorska", '10');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Romanijska", '10');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Ranka Šipke", '10');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Moslovačka", '10');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Nikole Bokana", '10');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Krajiška", '10');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Maksima Gorkog", '10');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Majevička", '11');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Zore Kovačević", '11');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Kupreška", '11');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Jovice Savinovića", '11');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Vojvode Sinđelića", '11');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Novosadska", '11');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Fruškogorska", '11');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Franca Šuberta", '12');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Vladimira Rolovića", '12');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Đorđa Jovetića", '12');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Ključka", '12');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Miloša Matića", '12');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Sime Milić Jorgić", '12');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Rade Kondića", '13');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Bože Nikolića", '13');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Branislava Nušića", '13');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Njegoševa", '13');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Jaroslav Plecitija", '13');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Kralja Petra II", '13');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Zvjezdana Mandića", '14');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Prote Vida Kovačevića", '14');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Manastira Gomionice", '14');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Cara Nikolaja II", '14');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Momčila Nastasijevića", '14');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Od Zmijanja Rajka", '14');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Bulevar Desanke Maksimović", '15');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Studenička", '15');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Jug Bogdana", '15');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Cerska", '15');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Sime Miljuša", '15');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Srpskih ustanika", '15');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Starog Vujadina", '15');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Tuzlanska", '15');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Gajeva", '16');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Ivana Franje Jukića", '16');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Đure Daničića", '16');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Gorana Radulovića Bimbe", '16');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Sime Šolaje", '16');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Srpska", '16');

INSERT INTO Street (name, partOfTheCityId) VALUES ("Sestara Levi", '17');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Sarajevska", '17');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Ivana Milutinovića", '17');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Petra Velikog", '17');
INSERT INTO Street (name, partOfTheCityId) VALUES ("Zdravka Dejanovića", '17');