INSERT INTO UserStatus (Name) VALUES ("inactive");
INSERT INTO UserStatus (Name) VALUES ("active");
INSERT INTO UserStatus (Name) VALUES ("blocked");
