INSERT INTO Role ( Name ) VALUES ( "Admin" );
INSERT INTO Role ( Name ) VALUES ( "DepartmentOfficer" );
INSERT INTO Role ( Name ) VALUES ( "User" );