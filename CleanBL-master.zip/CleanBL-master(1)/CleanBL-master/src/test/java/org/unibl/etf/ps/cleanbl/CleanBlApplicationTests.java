package org.unibl.etf.ps.cleanbl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanBlApplicationTests {

	@Test
	void contextLoads() {
	}

}
