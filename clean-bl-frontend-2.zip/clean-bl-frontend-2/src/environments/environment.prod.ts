export const environment = {
  production: true,
  API_KEY: 'AIzaSyDeA2ZmTxTQYmnxBzNwPDE6ub3DNBSBBcs',
};
