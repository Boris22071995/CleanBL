import { StatusDirectiveDirective } from './status-directive.directive';

describe('StatusDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new StatusDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
