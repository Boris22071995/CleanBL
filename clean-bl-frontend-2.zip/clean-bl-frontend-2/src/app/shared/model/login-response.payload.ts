export interface LoginResponse {
  authenticationToken: string;
  expiresAt: string;
  refreshToken: string;
  username: string;
  roles: string[];
}
