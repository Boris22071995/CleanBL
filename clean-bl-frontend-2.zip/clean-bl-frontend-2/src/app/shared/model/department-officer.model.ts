export interface DepartmentOfficer {
  id?: number;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  department: string;
}
