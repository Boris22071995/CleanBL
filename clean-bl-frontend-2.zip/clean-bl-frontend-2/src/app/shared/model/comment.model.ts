export class Comment {
  constructor(
    public username: string,
    public createdAt: Date,
    public content: string
  ) {}
}
