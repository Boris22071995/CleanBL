export interface DepartmentServiceModel {
  id: number;
  name: string;
  phone: string;
  email: string;
}
