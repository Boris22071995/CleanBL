export interface Department {
  id: number;
  name: string;
  phone: string;
  email: string;
}
