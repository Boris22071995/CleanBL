export interface SignupRequestPayload {
  email: string;
  firstName: string;
  lastName: string;
  password: string;
  username: string;
}
